    
    /*nav-toggle*/
    let nav = document.getElementById('nav_toggle');
    let menu = document.getElementById('header__inner-active');


    nav.addEventListener('click', function(){
        nav.classList.toggle('active');
        menu.classList.toggle('active');
    })

    /* /nav-toggle*/


    /*раскрытие ответов*/
    let coll = document.getElementsByClassName('questions_title');



    for (let i = 0; i < coll.length; i++) {
        coll[i].addEventListener('click', function() {
            
            this.classList.toggle('active');
            let questions_main = this.nextElementSibling;
            if (questions_main.style.maxHeight) {
                questions_main.style.maxHeight = null;
            }
            else {
                questions_main.style.maxHeight = questions_main.scrollHeight + 'px'
            }
        })   
    }




/*$('.section_5_main').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1
})*/
$(document).ready(function(){
    $('#section_slider').slick({
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1
    })
})

$(document).ready(function(){
    $('#section_5_main').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1
    })
})

/*slider*/

/*$(window).resize(function() {
        screen();
    });
 

function screen(){
    if (document.documentElement.clientWidth < 850){
        $('.slick-arrow').style.display = "none";         
    }
}
*/
 
/*$(document).ready(function(){

     $(this).addClass('active')

if (document.documentElement.clientWidth < 960) {
    $('.section_5_main').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1
    });
}

else{
    $('.section_5_main').slick({
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1
    });
}

});*/